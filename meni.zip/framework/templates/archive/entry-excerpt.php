<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

	<div class="entry-body"><?php echo meni_excerpt( $excerpt_length );?></div>